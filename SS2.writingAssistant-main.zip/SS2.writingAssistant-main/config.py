import os

GOOGLE_CLIENT_SECRET = "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"
GOOGLE_CLIENT_ID = "48603665006-p0tkod3fl4iskfs52b8ear7ruhgg5acu.apps.googleusercontent.com"
